# Rogue Galaxy PC port

A native PC port of *Rogue Galaxy* (PS2, North America, SCUS-97490 v1.01) for Windows and
Linux. It is not an emulator: the game's code comes from a matching decompilation and is
compiled for the PC, with native graphics (Direct3D 11 / Vulkan), audio, input, saves and
movies.

**You need your own copy of the game.** The downloads contain no game content; setup
rebuilds everything from your own disc image.

## Play

| | Download | Steps |
| --- | --- | --- |
| Windows 10/11 | `release/RogueGalaxyPC-1112b-win32.zip` | Unzip, put your `.iso` in the folder, run `Setup.exe` once, then `rg-game.exe`. See [QUICKSTART.md](QUICKSTART.md). |
| Linux x86-64 (Vulkan, X11 or Wayland) | `release/RogueGalaxyPC-1112b-linux-x86_64.zip` | Unzip, put your `.iso` in the folder, run `./rg-setup` once, then `./rg-game`. See [QUICKSTART-linux.md](QUICKSTART-linux.md). |

Build 1112b (2026-11-12). Automated tests reach every story boss on both platforms; please
report bugs with the steps that led there.

## Features

- **Display:** windowed or fullscreen, internal resolution up to 8x, widescreen (16:9,
  16:10, 21:9) with menus and HUD laid out for the wider screen, frame rates up to 240 or
  uncapped, anti-aliasing, anisotropic filtering, and enhanced bloom, depth of field and shadows.
  The memory-card screens use the full width too.
- **HD texture packs:** dump and replace textures (PCSX2-compatible names).
- **Controls:** keyboard, mouse and any gamepad, fully rebindable, with button prompts
  matching your device.
- **Audio:** separate volumes and output device selection.
- **Options:** text speed, battle speed-up, UI scale, colour-blind modes and reduced
  flashing; inventory sorting.
- **Insectron:** copy and paste Insectron passwords.
- **Online Battle:** Insectron 2-Player Battle over LAN, a VPN or a forwarded port (TCP 7490).
- **Saves:** stored as files with automatic backups; import from a PCSX2 memory card.
- **Settings menu:** F1 (or hold Back + Start). An "Original" preset restores the PS2 look
  and behaviour.

## Notes

- Windows SmartScreen warns about the unsigned executables: choose "More info", then "Run
  anyway".
- If the game crashes on Windows, please attach `rg-game-crash.txt` and `rg-game-crash.dmp`
  (next to the game) to your report.

## Supported disc

Rogue Galaxy (USA), SCUS-97490 v1.01: 6,967,721,984 bytes, SHA-1
`87377e721be58e8b6a5a7501721563500d237df7`. Other versions are refused by setup.

## How the download avoids game content

Every byte of the built executable that matches the retail game is zeroed before
packaging, and a table records only where each run comes from. Setup verifies your disc,
copies those bytes back from it, and checks the result's SHA-256 before writing the
executable.

## License

The port's own code and documentation are [CC0 1.0](LICENSE). This does **not** cover the
game code compiled into the executable, which is derived from *Rogue Galaxy* (© Level-5 /
Sony Interactive Entertainment); no rights to it are granted. This project is not
affiliated with or endorsed by them. Third-party libraries keep their own licenses
([THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md)); no GPL code is used.
